<?php
 return array (
  '_id' => 'PageBanner5bc9f6fe804aa',
  'name' => 'PageBanner',
  'description' => 'To be used in the normal page banners without summary',
  'effects' => 
  array (
  ),
  '_created' => 1539962622,
  '_modified' => 1540327991,
  'mode' => 'thumbnail',
  'width' => '1440',
  'height' => '220',
  'anchor' => 'center',
  'quality' => 90,
  'base64' => false,
  'domain' => false,
);