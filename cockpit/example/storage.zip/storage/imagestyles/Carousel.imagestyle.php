<?php
 return array (
  '_id' => 'Carousel5bd8eb0d3629c',
  'name' => 'Carousel',
  'description' => 'Used on carousels',
  'effects' => 
  array (
  ),
  '_created' => 1540942605,
  '_modified' => 1540943636,
  'mode' => 'thumbnail',
  'width' => '1080',
  'height' => '360',
  'anchor' => 'center',
  'quality' => 90,
  'base64' => false,
  'domain' => false,
);