<?php
 return array (
  '_id' => 'Contacts5bc9f7863d7df',
  'name' => 'Contacts',
  'label' => 'Contacts Form',
  'save_entry' => true,
  'in_menu' => true,
  'email_forward' => '',
  '_created' => 1539962758,
  '_modified' => 1539962758,
);