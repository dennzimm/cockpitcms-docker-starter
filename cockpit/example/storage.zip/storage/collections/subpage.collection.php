<?php
 return array (
  'name' => 'subpage',
  'label' => 'Sub Page',
  '_id' => 'subpage5bcc754bebfec',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'title',
      'label' => 'Title',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'localize' => false,
      'options' => 
      array (
        'slug' => true,
      ),
      'width' => '1-1',
      'lst' => true,
      'required' => true,
    ),
    1 => 
    array (
      'name' => 'components',
      'label' => 'Components',
      'type' => 'layout',
      'default' => '',
      'info' => '',
      'group' => 'Page Components',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => false,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
    2 => 
    array (
      'name' => 'slug',
      'label' => 'Slug',
      'type' => 'text',
      'default' => '',
      'info' => 'It will be populated automatically',
      'group' => 'Metadata',
      'localize' => false,
      'options' => 
      array (
        'cls' => 'uk-hidden',
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => false,
    ),
  ),
  'sortable' => false,
  'in_menu' => false,
  '_created' => 1540126027,
  '_modified' => 1541009590,
  'color' => '#FFCE54',
  'acl' => 
  array (
  ),
  'rules' => 
  array (
    'create' => 
    array (
      'enabled' => false,
    ),
    'read' => 
    array (
      'enabled' => false,
    ),
    'update' => 
    array (
      'enabled' => false,
    ),
    'delete' => 
    array (
      'enabled' => false,
    ),
  ),
  'description' => 'Used for internal pages (belong to a Page)',
  'contentpreview' => 
  array (
    'enabled' => true,
    'url' => 'http://localhost:3000/preview',
  ),
);